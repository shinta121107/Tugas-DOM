let balance = 0;

function addIncome() {
    const amount = parseFloat(document.getElementById('amount').value);
    if (!isNaN(amount) && amount > 0) {
        balance += amount;
        updateBalance();
    } else {
        alert('Masukkan jumlah uang yang valid untuk pendapatan.');
    }
}

function addExpense() {
    const amount = parseFloat(document.getElementById('amount').value);
    if (!isNaN(amount) && amount > 0) {
        balance -= amount;
        updateBalance();
    } else {
        alert('Masukkan jumlah uang yang valid untuk pengeluaran.');
    }
}

function updateBalance() {
    document.getElementById('balance').textContent = balance.toFixed(2);
    document.getElementById('amount').value = '';
}
